ชื่อทีม: 278_306_365
1. กิตติภณ สุรุ่งเรืองสกุล		61070278
2. ปรียานุช สุภาสืบ		61070306
3. อารีญา สมิงแก้ว		61070365 

Classification Task: Kuzushiji-Kanji
คำอธิบาย Soure code
1) CNN
- นำเข้าชุดข้อมูล Train
- เตรียมข้อมูลได้แก่ ปรับ scale ให้อยู่ระหว่าง 0-1  ทำ normalize และ reshape ข้อมูลให้อยู่ในรูปแบบที่พร้อมนำไปใช้งาน
- แบ่งข้อมูลเป็นชุด Training และ Validation โดยแบ่งเป็น 90% และ 10% ตามลำดับ
- ออกแบบและสร้างโมเดล เนื่องจากวิธี CNN มีโอกาสเกิด overfitting สูงจึงใช้ dropout เข้ามาช่วย
- Train โมเดลด้วยข้อมูลชุด Training
- นำโมเดลที่ได้มาทดสอบกับข้อมูลชุด Validation ถ้าได้ผลที่พึงพอใจก็จะนำโมเดลไปใช้ต่อ (ถ้าไม่พึงพอใจก็จะปรับโมเดลไปเรื่อยๆ)
- นำเข้าชุดข้อมูล Test
- เตรียมข้อมูลให้เหมือนกับชุด Train
- นำโมเดลมาทำนายชุดข้อมูล Test
- บันทึกผลทำนายลงไฟล์ csv

2) KNN
- นำเข้าชุดข้อมูล Train
- ในการเตรียมข้อมูลจะมีการ reshape ข้อมูลให้อยู่ในรูปแบบที่พร้อมนำไปใช้งาน
- แบ่งข้อมูลเป็นชุด Training และ Validation โดยแบ่งเป็น 80% และ 20% ตามลำดับ
- นำข้อมูลที่ได้หลังจากการแบ่งมาทำ PCA เพื่อลดขนาดข้อมูลและนำข้อมูลที่เป็นแกนหลักสำคัญมาใช้เท่านั้น
- ใช้ GridSearch ในการจูนโมเดล เพื่อหา hy[erparameter ที่ดีที่สุด โดยจะค้นหา 2 ตัวได้แก่ ค่า K และ Weight Options
- นำ hyperparameter ที่ได้มาสร้างโมเดล
- Train โมเดลด้วยข้อมูลชุด Training
- นำโมเดลที่ได้มาทดสอบกับข้อมูลชุด Validation ถ้าได้ผลที่พึงพอใจก็จะนำโมเดลไปใช้ต่อ (ถ้าไม่พึงพอใจก็จะหาวิธีเตรียมข้อมูลให้เหมาะสมมากยิ่งขึ้น)
- นำเข้าชุดข้อมูล Test
- เตรียมข้อมูลให้เหมือนกับชุด Train และทำ PCA เช่นกัน โดยใน่ส่วนนี้จะไม่ได้ fit model ใหม่แต่จะ transform ชุดข้อมูล Test เลย
- นำโมเดลมาทำนายชุดข้อมูล Test
- บันทึกผลทำนายลงไฟล์ csv
---------------------------------------------------------------------------------------------------
Regression Task: COVID-19 Prediction
คำอธิบาย Source code 
1 นำเข้าข้อมูลจาก GitHub
2 ทำความสะอาดข้อมูลต่างๆ เช่น การเเทนค่าว่าง การเลือกประเทศที่สนใจทำนาย
3 กำหนด date จากวันที่ ให้เป็นจำนวนตัวเลขเรียงตามวันไว้ใช้ในกรณีเทรน model
4 กำหนดจำนวนวันที่ต้องการให้ทำนาย คือ 35 วัน ตั้งเเต่ 12/04 - 16/05 ปี 2021 

วิธีที่ 1) linear regression 
- แปลง date to column โดยค่าข้างในจะเป็น Total_cases
- เลือกทำทีละประเทศ
- นำข้อมูลที่เลือกโดยใช้เฉพาะ column date ที่เรียงต่อกันจำนวน 446 column 
- มีตัวแปร x คือจำนวนวัน day_num เเละ ตัวแปร y คือ total_cases 
- เเบ่งข้อมูลตามความเหมาะสมของเเต่ละประเทศเพื่อใช้ในการ train model ช่วงก่อน 12/04/2021 train เเละ validation โดยแบ่งเป็น 80 % และ 20% 
- นำข้อมูล validation มาาทดสอบ model โดยประเมินผลด้วย mse  
- เลือก model ที่ให้ค่า loss น้อยที่สุดมาใช้ในการทำนายวันที่ต้องการทราบ
- ได้จำนวนผู้ติดเชื้อมา
- จัดเก็บผลลัพธ์ และทำเช่นนี้กับทุกๆประเทศ

วิธีที่ 2) Prophet model
- นำข้อมูลเข้าซึ่งเป้นข้อมูลในรูปแบบปกติ สำหรับ train model ก่อนวันที่ 12/04/2021
- นำข้อมุลช่วง 12/04 - 6/05 ปี 2021 เพื่อใช้ในการหาค่า mse หลังจากที่เราได้ทำนายข้อมูลเเล้ว
- เลือกประเทศที่ต้องการทำนายทีละประเทส 
- เลือกคอลัมน์ที่จะใช้ในการ train มี date และ total_cases 
- กำหนดรูปแบบ columns ให้อยู่ในรูปแบบของ model prophet
- train model ด้วยข้อมูลที่ได้จากการเลือกช่วงข้อมูลที่นำมาใช้ train 
- ได้ model สำหรับประเทศนั้นๆ 
- ตั้งตัวแปร forecast เพื่อระบุจำนวนวันที่ต้องการให้ model ทำนายเพิ่ม
- model ทำนาย forecast ช่วงเวลาที่ต้องการทราบ 
- ได้ตัวเลขของผู้ติดเชื้อตามช่วงเวลาที่ให้ model ทำนายเพิ่ม มาจำนวน 3 ค่า yhat , yhat_lower ,yhat_upper
- คำนวณค่า mse กับทั้ง 3 ค่าอล้วเลือกใช้ label ที่ให้ค่า mse น้อยที่สุดจาก 3 ค่่านั้น
- จัดเก็บ Label เเละทำซ้ำเช่นนี้กับทุกประเทศ 

***หมายเหตุ ในการทำนายแต่ละวิธี จะใช้ข้อมูลเทรนในช่วงก่อน 11/04/2021 เเละทำนายตั้งเเต่ 12/04/2021 ไปจนถึง 16/05/2021 เเล้วแบ่งข้อมูลตามช่วงที่สนใจเพื่อจัดเก็บ Label ของทั้ง 2 ช่วง
-------------------------------------------------------------------------------------------------------
Clustering Task: Star Type Clustering
คำอธิบาย Source code
folder name: Star_Type_Clustering
1. นำเข้าชุดข้อมูล stars_data.csv ที่เซฟมาจาก github
2. data pre-processing เตรียมข้อมูลในคอลัมน์ 2 คอลัมน์คือ Color และ Spectral_Class 
2.1 column Color ทำการรวมข้อมูลประเภทสีสเปคตรัมที่เขียนซ้ำกัน แต่มีความหมายเหมือนกันเป็นในรูปแบบของประเภทสีสเปคตรัม 1 ดังนี้
	Blue = ['Blue']
	Bluewhite = ['Blue White', 'Blue white', 'Blue-white', 'Blue-White', 'Blue-white']
	White = ['Whitish','white','White']
	Yellowwhite = ['yellow-white', 'White-Yellow','Yellowish White']
	Yellow = ['yellowish', 'Yellowish','Yellow']
	Orange = ['Orange']
	Orangered = ['Orange-Red']
	Paleyelloworange = ['Pale yellow orange']
	Red = ['Red']
 	และทำการแปลงข้อมูลประเภทสีสเปคตรัมจาก String เป็น Integer
2.2 column Spectral_Class แปลงข้อมูลประเภทของสเปคตรัมจาก String เป็น Integer
3. Feature Scale Data ด้วย 3 วิธี คือ 
- normalization
- standardscaler
- powertranformer
โดยวิธี powertranformer จะได้ผลลัพธ์การ scale data ได้ดีที่สุด
4. Optimal Number of Clusterด้วย 2 วิธีคือ Elbow Method และ Sillhouette Method และทำการ Visualize ดูค่า K เพื่อใช้ในการตัดสินใจนำค่า K ไปแบ่งกลุ่มในโมเดล
5. Modeling นำค่า K ที่ตัดสินใจได้มาใช้ในโมเดล MiniBatchK-Means ซึ่งจะมีการ Visualize Label เป็น barchart เพื่อดูว่าข้อมูลถูกแบ่งออกเป็นกี่กลุ่ม และมีจำนวนกลุ่มละเท่าใด แล้วทำการวัดผลโดยนำ Label ที่ได้จากการ Cluster ไปวัดประสิทธิภาพการแบ่งกลุ่มดูจากค่า purity, nmi และ rand_index

folder name: Star_Type_ClusteringColor2
1. นำเข้าชุดข้อมูล stars_data.csv ที่เซฟมาจาก github
2. data pre-processing เตรียมข้อมูลในคอลัมน์ 2 คอลัมน์คือ Color และ Spectral_Class 
2.1 column Color ทำการรวมข้อมูลประเภทสีสเปคตรัมที่เขียนซ้ำกัน แต่มีความหมายเหมือนกันเป็นในรูปแบบของประเภทสีสเปคตรัม 2 ดังนี้
	Blue = ['Blue']
	Bluewhite = ['Blue White', 'Blue white', 'Blue-white', 'Blue-White', 'Blue-white']
	White = ['white','White']
	Whitish = ['Whitish']
	Yellowwhite = ['yellow-white', 'White-Yellow']
	Yellowishwhite = ['Yellowish White']
	Yellow = ['yellowish', 'Yellowish','Yellow']
	Orange = ['Orange']
	Orangered = ['Orange-Red']
	Paleyelloworange = ['Pale yellow orange']
	Red = ['Red'] 
	และทำการแปลงข้อมูลประเภทสีสเปคตรัมจาก String เป็น Integer
2.2 column Spectral_Class แปลงข้อมูลประเภทของสเปคตรัมจาก String เป็น Integer
3. Feature Scale Data ด้วย 3 วิธี คือ 
- normalization
- standardscaler
- powertranformer
โดยวิธี powertranformer จะได้ผลลัพธ์การ scale data ได้ดีที่สุด
4. Optimal Number of Clusterด้วย 2 วิธีคือ Elbow Method และ Sillhouette Method และทำการ Visualize ดูค่า K เพื่อใช้ในการตัดสินใจนำค่า K ไปแบ่งกลุ่มในโมเดล
5. Modeling นำค่า K ที่ตัดสินใจได้มาใช้ในโมเดล  MiniBatchK-Means ซึ่งจะมีการ Visualize Label เป็น barchart เพื่อดูว่าข้อมูลถูกแบ่งออกเป็นกี่กลุ่ม และมีจำนวนกลุ่มละเท่าใด แล้วทำการวัดผลโดยนำ Label ที่ได้จากการ Cluster ไปวัดประสิทธิภาพการแบ่งกลุ่มดูจากค่า purity, nmi และ rand_index

folder name: Star_Type_ClusteringKmeans
1. นำเข้าชุดข้อมูล stars_data.csv ที่เซฟมาจาก github
2. data pre-processing เตรียมข้อมูลในคอลัมน์ 2 คอลัมน์คือ Color และ Spectral_Class 
2.1 column Color column Color ทำการรวมข้อมูลประเภทสีสเปคตรัมที่เขียนซ้ำกัน แต่มีความหมายเหมือนกันเป็นในรูปแบบของประเภทสีสเปคตรัม 1 ดังนี้
	Blue = ['Blue']
	Bluewhite = ['Blue White', 'Blue white', 'Blue-white', 'Blue-White', 'Blue-white']
	White = ['Whitish','white','White']
	Yellowwhite = ['yellow-white', 'White-Yellow','Yellowish White']
	Yellow = ['yellowish', 'Yellowish','Yellow']
	Orange = ['Orange']
	Orangered = ['Orange-Red']
	Paleyelloworange = ['Pale yellow orange']
	Red = ['Red'] 
	และทำการแปลงข้อมูลประเภทสีสเปคตรัมจาก String เป็น Integer
2.2 column Spectral_Class แปลงข้อมูลประเภทของสเปคตรัมจาก String เป็น Integer
3. Feature Scale Data ด้วย 3 วิธี คือ 
- normalization
- standardscaler
- powertranformer
โดยวิธี powertranformer จะได้ผลลัพธ์การ scale data ได้ดีที่สุด
4. Optimal Number of Clusterด้วย 2 วิธีคือ Elbow Method และ Sillhouette Method และทำการ Visualize ดูค่า K เพื่อใช้ในการตัดสินใจนำค่า K ไปแบ่งกลุ่มในโมเดล
5. Modeling นำค่า K ที่ตัดสินใจได้มาใช้ในโมเดล K-Meansซึ่งจะมีการ Visualize Label เป็น barchart เพื่อดูว่าข้อมูลถูกแบ่งออกเป็นกี่กลุ่ม และมีจำนวนกลุ่มละเท่าใด แล้วทำการวัดผลโดยนำ Label ที่ได้จากการ Cluster ไปวัดประสิทธิภาพการแบ่งกลุ่มดูจากค่า purity, nmi และ rand_index









